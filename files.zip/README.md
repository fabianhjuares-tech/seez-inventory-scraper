# Autohaus Burger inventory scraper

Collects every new and used car from https://autohaus-burger.de and writes `inventory.json`
(English keys, numbers as numbers, all image URLs, equipment, extra details).

## Run

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
playwright install chromium

python scraper.py --limit 5      # quick smoke test
python scraper.py                # full run -> inventory.json
```

Options: `--out FILE`, `--limit N`, `--debug` (saves screenshots/HTML of the search grids to `./debug`),
`--headful` (show the browser), `--no-browser` (sitemap + landing pages only).
Optional: `export SCRAPER_CONTACT="you@example.com"` so the User-Agent identifies you.

## How it works

1. **Discovery** - Playwright opens `/detailsuche-gebrauchtwagen/` and `/detailsuche-neuwagen/` (JS-rendered grids),
   clicks "load more"/"next" or scrolls until no new links appear. Landing pages and the WordPress sitemap
   are merged in as a safety net.
2. **Extraction** - each `/fahrzeuge/<id>/` page is server-rendered, so plain `requests` + BeautifulSoup is used:
   title, price, spec table (German -> English keys), grouped equipment, consumption/CO2 and every image URL
   (carousel clones are de-duplicated).
3. **Responsible scraping** - robots.txt check, identifying User-Agent, random 1.5-3 s delay before every request,
   retries with exponential backoff, no parallel requests.

## Output (excerpt)

```json
{
  "listing_url": "https://autohaus-burger.de/fahrzeuge/09513/",
  "condition": "used", "year": 2026, "first_registration": "2026-06",
  "make": "Volkswagen", "model": "T-Cross", "variant": "R-Line 1.0TSI DSG ACC/IQ.LIGHT/RFK",
  "mileage_km": 20, "price": {"amount": 26890, "currency": "EUR", "vat_included": true},
  "fuel_type": "petrol", "transmission": "automatic", "power_ps": 116,
  "equipment": ["Airbag", "..."], "images": ["https://cdn.ars-mia.de/v0/vehicles/...01.jpg", "..."]
}
```
