#!/usr/bin/env python3
"""
Autohaus Burger inventory scraper  ->  inventory.json

Two phases:
  1. DISCOVERY  - find every vehicle URL (new + used).
       * Playwright drives the JS "Detailsuche" grids (load-more / pagination / scroll)
       * the WordPress sitemap is used as a safety net
  2. EXTRACTION - fetch each /fahrzeuge/<id>/ page with plain HTTP (it is
       server-rendered) and parse specs, equipment and ALL image URLs.

Usage:
    python scraper.py                  # full run -> inventory.json
    python scraper.py --limit 5        # quick test on 5 cars
    python scraper.py --debug          # also dump HTML/screenshots into ./debug
"""
import argparse
import json
import logging
import os
import random
import re
import time
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urljoin
from urllib.robotparser import RobotFileParser

import requests
from bs4 import BeautifulSoup
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE = "https://autohaus-burger.de"
SEARCH_PAGES = {
    "used": f"{BASE}/detailsuche-gebrauchtwagen/",
    "new": f"{BASE}/detailsuche-neuwagen/",
}
SEED_PAGES = {"used": f"{BASE}/gebrauchtwagen/", "new": f"{BASE}/neuwagen/"}
SITEMAPS = [f"{BASE}/wp-sitemap.xml", f"{BASE}/sitemap_index.xml", f"{BASE}/sitemap.xml"]

VEHICLE_URL_RE = re.compile(r"^https://autohaus-burger\.de/fahrzeuge/([A-Za-z0-9_-]+)/?$")
IMAGE_RE = re.compile(r"https://cdn\.ars-mia\.de/v0/vehicles/[\w.\-]+\.(?:jpe?g|png|webp)", re.I)

CONTACT = os.environ.get("SCRAPER_CONTACT", "candidate-exercise")
USER_AGENT = f"Mozilla/5.0 (compatible; SeezCandidateExercise/1.0; {CONTACT})"
MIN_DELAY, MAX_DELAY = 1.5, 3.0

log = logging.getLogger("scraper")


def throttle():
    time.sleep(random.uniform(MIN_DELAY, MAX_DELAY))


# --------------------------------------------------------------------------- #
# Cleaning helpers (German number / unit formats -> proper types)
# --------------------------------------------------------------------------- #
def parse_de_int(text):
    """'26.890 €' -> 26890 ; '27.920 km' -> 27920 ; '999 ccm' -> 999"""
    m = re.search(r"\d{1,3}(?:\.\d{3})+|\d+", text or "")
    return int(m.group().replace(".", "")) if m else None


def parse_de_float(text):
    """'5,8 l/100km' -> 5.8"""
    m = re.search(r"\d+(?:[.,]\d+)?", text or "")
    return float(m.group().replace(",", ".")) if m else None


def parse_power(text):
    kw = re.search(r"(\d+)\s*kW", text or "")
    ps = re.search(r"(\d+)\s*PS", text or "")
    return (int(kw.group(1)) if kw else None, int(ps.group(1)) if ps else None)


def parse_first_registration(text):
    """'06/2026' -> ('2026-06', 2026)"""
    m = re.search(r"(\d{1,2})\s*/\s*(\d{4})", text or "")
    if not m:
        return None, None
    return f"{m.group(2)}-{int(m.group(1)):02d}", int(m.group(2))


def slug(text):
    t = text.lower().replace("ä", "ae").replace("ö", "oe").replace("ü", "ue").replace("ß", "ss")
    return re.sub(r"[^a-z0-9]+", "_", t).strip("_")


# German -> English mappings
SPEC_KEYS = {
    "Leistung": "power", "Hubraum": "engine_displacement_cc", "Getriebe": "transmission",
    "Antrieb": "drivetrain", "Kraftstoff": "fuel_type", "Erstzulassung": "first_registration",
    "Laufleistung": "mileage_km", "Schadstoffklasse": "emissions_class", "HSN/TSN": "hsn_tsn",
    "Farbe": "exterior_color", "Außenfarbe": "exterior_color", "Innenfarbe": "interior_color",
    "Türen": "doors", "Sitzplätze": "seats", "Fahrzeugtyp": "body_type", "Karosserie": "body_type",
    "Anzahl Vorbesitzer": "previous_owners", "Vorbesitzer": "previous_owners",
    "Leergewicht": "curb_weight_kg", "Zylinder": "cylinders",
}
FUEL = {"super": "petrol", "super plus": "petrol", "benzin": "petrol", "diesel": "diesel",
        "elektro": "electric", "hybrid": "hybrid", "plug-in-hybrid": "plug_in_hybrid",
        "erdgas": "cng", "autogas": "lpg"}
TRANSMISSION = {"automatik": "automatic", "schaltgetriebe": "manual", "halbautomatik": "semi_automatic"}
DRIVETRAIN = {"frontantrieb": "fwd", "hinterradantrieb": "rwd", "allradantrieb": "awd"}
CONDITION = {"gebraucht": "used", "neu": "new", "vorführwagen": "demo", "vorführfahrzeug": "demo",
             "tageszulassung": "pre_registered", "jahreswagen": "used"}
KNOWN_MAKES = ["Volkswagen", "Audi", "Skoda", "Škoda", "SEAT", "Cupra", "CUPRA", "VW", "Mercedes-Benz",
               "BMW", "Ford", "Opel", "Renault", "Peugeot", "Hyundai", "Kia", "Toyota", "Porsche"]


# --------------------------------------------------------------------------- #
# HTTP session (identifying UA, retries with backoff, robots.txt)
# --------------------------------------------------------------------------- #
def make_session():
    s = requests.Session()
    s.headers.update({"User-Agent": USER_AGENT, "Accept-Language": "de-DE,de;q=0.9,en;q=0.5"})
    retry = Retry(total=4, backoff_factor=2, status_forcelist=(429, 500, 502, 503, 504),
                  allowed_methods=("GET",), respect_retry_after_header=True)
    s.mount("https://", HTTPAdapter(max_retries=retry))
    return s


def load_robots(session):
    rp = RobotFileParser()
    try:
        r = session.get(f"{BASE}/robots.txt", timeout=20)
        rp.parse(r.text.splitlines() if r.ok else [])
    except requests.RequestException:
        rp.parse([])
    return rp


# --------------------------------------------------------------------------- #
# Phase 1 - discovery
# --------------------------------------------------------------------------- #
def norm_url(href):
    href = href.split("#")[0].split("?")[0]
    if not href.endswith("/"):
        href += "/"
    return href if VEHICLE_URL_RE.match(href) else None


def parse_card_text(text):
    """Pull the condition badge + CO2 class out of a listing card's text."""
    badge = next((w for w in CONDITION if re.search(rf"\b{w}\b", text or "", re.I)), None)
    co2 = re.search(r"CO2-Klasse:\s*([A-G]\+*)", text or "")
    return (badge.capitalize() if badge else None), (co2.group(1) if co2 else None)


def discover_with_playwright(found, debug=False, headful=False):
    from playwright.sync_api import sync_playwright

    js_collect = """() => [...document.querySelectorAll('a[href*="/fahrzeuge/"]')].map(a => {
        let el = a, text = a.innerText || '';
        for (let i = 0; i < 6 && el.parentElement && !text.includes('€'); i++) {
            el = el.parentElement; text = el.innerText || '';
        }
        return {href: a.href, text: text.slice(0, 600)};
    })"""
    more_selectors = [
        "a[rel=next]", "[aria-label*='nächste' i]", "[aria-label*='next' i]",
        "button:has-text('Mehr laden')", "button:has-text('Weitere')", "button:has-text('Mehr anzeigen')",
        "a:has-text('Mehr laden')", "a:has-text('Mehr anzeigen')", "a:has-text('Weitere Fahrzeuge')",
        "li.next a", "a.next", "button.next", "a:has-text('Nächste')", "button:has-text('Nächste')",
    ]

    def collect(page, default_condition):
        new = 0
        for item in page.evaluate(js_collect):
            url = norm_url(item["href"])
            if not url:
                continue
            badge, co2 = parse_card_text(item["text"])
            if url not in found:
                found[url] = {"condition": default_condition, "badge": badge, "co2_class": co2, "source": "search"}
                new += 1
            else:  # enrich earlier entries
                found[url]["badge"] = found[url]["badge"] or badge
                found[url]["co2_class"] = found[url]["co2_class"] or co2
        return new

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=not headful)
        ctx = browser.new_context(user_agent=USER_AGENT, locale="de-DE")
        page = ctx.new_page()
        for condition, url in SEARCH_PAGES.items():
            log.info("Discovery: %s (%s)", url, condition)
            page.goto(url, wait_until="networkidle", timeout=60000)
            for label in ("Alle akzeptieren", "Akzeptieren", "Zustimmen"):  # cookie banner, best effort
                try:
                    page.get_by_role("button", name=re.compile(label, re.I)).first.click(timeout=2000)
                    break
                except Exception:
                    pass
            stale_rounds = 0
            for _ in range(300):  # hard safety cap
                new = collect(page, condition)
                clicked = False
                for sel in more_selectors:
                    loc = page.locator(sel).first
                    try:
                        if loc.is_visible() and loc.is_enabled():
                            loc.scroll_into_view_if_needed()
                            loc.click(timeout=3000)
                            clicked = True
                            break
                    except Exception:
                        continue
                if not clicked:  # infinite-scroll style grids
                    page.mouse.wheel(0, 20000)
                throttle()
                try:
                    page.wait_for_load_state("networkidle", timeout=10000)
                except Exception:
                    pass
                new += collect(page, condition)
                stale_rounds = 0 if new else stale_rounds + 1
                log.info("  %d vehicle links so far (+%d)", len(found), new)
                if stale_rounds >= 3:
                    break
            if debug:
                Path("debug").mkdir(exist_ok=True)
                page.screenshot(path=f"debug/{condition}_search.png", full_page=True)
                Path(f"debug/{condition}_search.html").write_text(page.content(), encoding="utf-8")
        browser.close()


def discover_from_seed_pages(session, found):
    """Landing pages render a teaser server-side; cheap extra coverage."""
    for condition, url in SEED_PAGES.items():
        try:
            soup = BeautifulSoup(session.get(url, timeout=30).text, "lxml")
        except requests.RequestException as e:
            log.warning("Seed page failed %s: %s", url, e)
            continue
        for a in soup.select("a[href*='/fahrzeuge/']"):
            u = norm_url(a["href"])
            if u and u not in found:
                found[u] = {"condition": condition, "badge": None, "co2_class": None, "source": "seed"}
        throttle()


def discover_from_sitemaps(session, found):
    def locs(url):
        try:
            r = session.get(url, timeout=30)
            if not r.ok:
                return []
            return [e.text.strip() for e in ET.fromstring(r.content).iter() if e.tag.endswith("loc") and e.text]
        except (requests.RequestException, ET.ParseError):
            return []

    for sm in SITEMAPS:
        for loc in locs(sm):
            children = locs(loc) if loc.endswith(".xml") else [loc]
            for c in children:
                u = norm_url(c)
                if u and u not in found:
                    found[u] = {"condition": None, "badge": None, "co2_class": None, "source": "sitemap"}
        throttle()


# --------------------------------------------------------------------------- #
# Phase 2 - detail page parsing
# --------------------------------------------------------------------------- #
def parse_detail(html, url, meta):
    soup = BeautifulSoup(html, "lxml")
    text = soup.get_text("\n", strip=True)
    vid = VEHICLE_URL_RE.match(url).group(1)

    h1 = soup.find("h1")
    title = h1.get_text(" ", strip=True) if h1 else (soup.title.string.rsplit(" - ", 1)[0] if soup.title else None)

    # make / model / variant: title gives make+variant, meta description gives "<Make> <Model> – price ..."
    make = next((m for m in KNOWN_MAKES if title and title.startswith(m + " ")), None) or (title or "").split(" ")[0]
    desc = (soup.find("meta", attrs={"name": "description"}) or {}).get("content", "") if soup else ""
    head = re.match(r"^(.+?)\s+[–-]\s+", desc or "")
    model = None
    if head and head.group(1).startswith(make):
        model = head.group(1)[len(make):].strip() or None
    variant = title
    if title:
        prefix = f"{make} {model}".strip() if model else make
        variant = title[len(prefix):].strip() if title.startswith(prefix) else title

    # price
    price_node = h1.find_next(string=re.compile(r"\d[\d.]*\s*€")) if h1 else None
    price_amount = parse_de_int(price_node) if price_node else None

    # spec table: rows of (German label, value)
    raw_specs = {}
    for tr in soup.select("table tr"):
        cells = [c.get_text(" ", strip=True) for c in tr.find_all(["th", "td"])]
        if len(cells) >= 2 and cells[0]:
            raw_specs[cells[0]] = cells[1]

    rec = {
        "listing_url": url, "vehicle_id": vid, "condition": meta.get("condition"),
        "condition_label_de": meta.get("badge"),
        "make": make, "model": model, "variant": variant, "title": title,
        "year": None, "first_registration": None, "mileage_km": None,
        "price": {"amount": price_amount, "currency": "EUR",
                  "vat_included": True if re.search(r"inkl\.?\s*MwSt", text) else None},
        "fuel_type": None, "transmission": None, "drivetrain": None,
        "power_kw": None, "power_ps": None, "engine_displacement_cc": None,
        "emissions_class": None, "hsn_tsn": None,
    }
    other = {}
    for label, value in raw_specs.items():
        key = SPEC_KEYS.get(label)
        if key == "power":
            rec["power_kw"], rec["power_ps"] = parse_power(value)
        elif key == "first_registration":
            rec["first_registration"], rec["year"] = parse_first_registration(value)
        elif key in ("mileage_km", "engine_displacement_cc"):
            rec[key] = parse_de_int(value)
        elif key == "fuel_type":
            rec[key] = FUEL.get(value.lower(), value.lower())
        elif key == "transmission":
            rec[key] = TRANSMISSION.get(value.lower(), value.lower())
        elif key == "drivetrain":
            rec[key] = DRIVETRAIN.get(value.lower(), value.lower())
        elif key:
            rec[key] = value
        else:
            other[slug(label)] = value
    if other:
        rec["other_details"] = other
    rec["raw_specs_de"] = raw_specs

    # consumption / emissions
    kwh = re.search(r"([\d.,]+)\s*kWh/100\s*km", text)
    l100 = re.search(r"([\d.,]+)\s*l/100\s*km", text)
    co2 = re.search(r"(\d+)\s*g/km", text)
    rec["consumption_l_per_100km_combined"] = parse_de_float(l100.group(1)) if l100 else None
    rec["consumption_kwh_per_100km_combined"] = parse_de_float(kwh.group(1)) if kwh else None
    rec["co2_g_per_km_combined"] = int(co2.group(1)) if co2 else None
    rec["co2_class"] = meta.get("co2_class")

    # equipment: <h1>Ausstattung</h1> then <h4>category</h4><ul>...</ul> until the emissions section
    by_cat, flat = {}, []
    start = next((h for h in soup.find_all(["h1", "h2", "h3"]) if h.get_text(strip=True) == "Ausstattung"), None)
    if start:
        cat = "Sonstiges"
        for el in start.find_all_next(["h1", "h2", "h3", "h4", "ul"]):
            if el.name in ("h1", "h2", "h3"):
                break
            if el.name == "h4":
                cat = el.get_text(" ", strip=True)
            elif el.name == "ul":
                items = [li.get_text(" ", strip=True) for li in el.find_all("li") if li.get_text(strip=True)]
                by_cat.setdefault(cat, []).extend(items)
                flat.extend(i for i in items if i not in flat)
    rec["equipment"] = flat
    rec["equipment_by_category"] = by_cat

    # images: every distinct CDN URL anywhere in the HTML (carousels clone slides -> dedupe, keep order)
    images = list(dict.fromkeys(IMAGE_RE.findall(html)))
    if not images:
        og = soup.find("meta", property="og:image")
        images = [og["content"]] if og and og.get("content") else []
    rec["images"] = images
    rec["image_count"] = len(images)

    pdf = soup.find("a", href=re.compile(r"ecc_pdf=1"))
    rec["pdf_url"] = urljoin(url, pdf["href"]) if pdf else None
    rec["scraped_at"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    return rec


def fix_condition(rec, meta):
    """Normalise condition label; heuristic only when no search page told us."""
    badge = (meta.get("badge") or "").lower()
    if badge in CONDITION:
        rec["condition"] = CONDITION[badge]
    elif not rec["condition"]:
        rec["condition"] = "used" if rec["vehicle_id"].isdigit() else "new"
        rec["condition_inferred"] = True


# --------------------------------------------------------------------------- #
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out", default="inventory.json")
    ap.add_argument("--limit", type=int, help="only scrape the first N vehicles (testing)")
    ap.add_argument("--debug", action="store_true", help="save screenshots/HTML of the search grids")
    ap.add_argument("--headful", action="store_true", help="show the browser window")
    ap.add_argument("--no-browser", action="store_true", help="skip Playwright (seed pages + sitemap only)")
    args = ap.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

    session = make_session()
    robots = load_robots(session)

    found = {}
    if not args.no_browser:
        try:
            discover_with_playwright(found, debug=args.debug, headful=args.headful)
        except Exception as e:  # keep going with the other sources
            log.error("Playwright discovery failed: %s", e)
    discover_from_seed_pages(session, found)
    discover_from_sitemaps(session, found)
    log.info("Discovered %d vehicle URLs", len(found))
    if not found:
        raise SystemExit("No vehicle URLs found - re-run with --debug --headful and inspect ./debug")

    urls = sorted(found)[: args.limit] if args.limit else sorted(found)
    cars, failures = [], []
    try:
        for i, url in enumerate(urls, 1):
            if not robots.can_fetch(USER_AGENT, url):
                log.warning("robots.txt disallows %s - skipped", url)
                continue
            throttle()
            try:
                r = session.get(url, timeout=30)
                r.raise_for_status()
                rec = parse_detail(r.text, url, found[url])
                fix_condition(rec, found[url])
                cars.append(rec)
                log.info("[%d/%d] %s %s %s - %s images", i, len(urls), rec["make"], rec["model"],
                         rec["variant"], rec["image_count"])
            except Exception as e:
                log.error("[%d/%d] %s failed: %s", i, len(urls), url, e)
                failures.append(url)
    finally:
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(cars, f, ensure_ascii=False, indent=2)

    # quick completeness report
    log.info("Saved %d vehicles to %s (%d failures)", len(cars), args.out, len(failures))
    for field in ("make", "model", "variant", "year", "mileage_km", "fuel_type", "transmission"):
        missing = sum(1 for c in cars if c.get(field) in (None, ""))
        log.info("  missing %-13s %d/%d", field, missing, len(cars))
    log.info("  without images        %d/%d", sum(1 for c in cars if not c["images"]), len(cars))
    for u in failures:
        log.info("  FAILED %s", u)


if __name__ == "__main__":
    main()
